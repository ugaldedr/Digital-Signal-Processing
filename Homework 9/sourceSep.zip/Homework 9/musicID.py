import numpy as np
import matplotlib.pyplot as plt
from numpy.linalg import norm
import soundfile as sf
from scipy.signal import spectrogram
import glob


def classifyMusic() :
    pass


###################  main  ###################
if __name__ == "__main__" :
    classifyMusic()
